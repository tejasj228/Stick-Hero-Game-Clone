module com.example.stickgame {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.stickgame to javafx.fxml;
    exports com.example.stickgame;
}