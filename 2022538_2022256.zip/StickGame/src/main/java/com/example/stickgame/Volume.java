package com.example.stickgame;


import javafx.scene.control.Button;

public class Volume {
    private static Volume instance;
    private String parameter;

    // Private constructor to prevent instantiation outside this class
    private Volume(String parameter) {
        this.parameter = parameter;
    }

    // Method to get the singleton instance with a parameter
    public static Volume getInstance(String parameter) {
        if (instance == null) {
            instance = new Volume(parameter);
        }
        return instance;
    }

    // Method to access the parameter
    public String getParameter() {
        return parameter;
    }

    public static void main(String[] args) {
        // Creating a singleton instance with a parameter
        Volume singletonInstance = Volume.getInstance("Example Parameter");

        // Accessing the parameter
        System.out.println(singletonInstance.getParameter()); // Output: Example Parameter

        // Trying to create another instance (won't be possible)
        Volume anotherInstance = Volume.getInstance("Another Parameter");

        // Accessing the parameter of the new instance
        System.out.println(anotherInstance.getParameter()); // Output: Example Parameter (since it's the same instance)
    }
}
